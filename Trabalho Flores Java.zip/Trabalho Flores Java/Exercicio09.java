/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Calculadora simples (+ - * /).

Explicação:
O programa lê dois números e uma operação.
Usa if para identificar a operação e calcular o resultado.
*******************************************************************************/

import java.util.Scanner;

public class Exercicio09 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Número 1: ");
        double n1 = sc.nextDouble();

        System.out.print("Número 2: ");
        double n2 = sc.nextDouble();

        System.out.print("Operação (+ - * /): ");
        char op = sc.next().charAt(0);

        double resultado = 0;

        if (op == '+') resultado = n1 + n2;
        else if (op == '-') resultado = n1 - n2;
        else if (op == '*') resultado = n1 * n2;
        else if (op == '/') resultado = n1 / n2;

        System.out.println("Resultado: " + resultado);
    }
}
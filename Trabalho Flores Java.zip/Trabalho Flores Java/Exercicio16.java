/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Validação de senha.

Explicação:
Verifica tamanho e se possui maiúscula, minúscula e número.
*******************************************************************************/

import java.util.Scanner;

public class Exercicio16 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a senha: ");
        String senha = sc.nextLine();

        boolean maiuscula = false, minuscula = false, numero = false;

        for (int i = 0; i < senha.length(); i++) {
            char c = senha.charAt(i);

            if (Character.isUpperCase(c)) maiuscula = true;
            if (Character.isLowerCase(c)) minuscula = true;
            if (Character.isDigit(c)) numero = true;
        }

        if (senha.length() >= 8 && maiuscula && minuscula && numero) {
            System.out.println("Senha válida");
        } else {
            System.out.println("Senha inválida");
        }
    }
}
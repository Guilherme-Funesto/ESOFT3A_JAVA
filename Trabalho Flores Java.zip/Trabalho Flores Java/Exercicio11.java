/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Classe Pessoa com nome e idade.

Explicação:
Cria uma classe com atributos e um método para exibir os dados.
*******************************************************************************/

class Pessoa {
    String nome;
    int idade;

    void mostrarDados() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
    }
}

public class Exercicio11 {
    public static void main(String[] args) {

        Pessoa p = new Pessoa();
        p.nome = "Lucas";
        p.idade = 20;

        p.mostrarDados();
    }
}
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Classe Aluno herdando de Pessoa.

Explicação:
A classe Aluno herda atributos de Pessoa e adiciona matrícula.
*******************************************************************************/

class Pessoa {
    String nome;
    int idade;
}

class Aluno extends Pessoa {
    String matricula;
}

public class Exercicio12 {
    public static void main(String[] args) {

        Aluno a = new Aluno();
        a.nome = "Lucas";
        a.idade = 20;
        a.matricula = "12345";

        System.out.println(a.nome + " - " + a.matricula);
    }
}
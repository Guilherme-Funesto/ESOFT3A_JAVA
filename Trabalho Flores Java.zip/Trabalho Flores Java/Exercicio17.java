/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Jogo de adivinhação.

Explicação:
O computador gera um número aleatório e o usuário tenta adivinhar.
O programa dá dicas até acertar.
*******************************************************************************/

import java.util.Scanner;
import java.util.Random;

public class Exercicio17 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        int numero = rand.nextInt(100) + 1;
        int palpite;

        do {
            System.out.print("Digite um número: ");
            palpite = sc.nextInt();

            if (palpite < numero)
                System.out.println("Maior");
            else if (palpite > numero)
                System.out.println("Menor");

        } while (palpite != numero);

        System.out.println("Acertou!");
    }
}
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Interface Veiculo e classe Carro.

Explicação:
A interface define métodos e a classe implementa esses métodos.
*******************************************************************************/

interface Veiculo {
    void acelerar();
    void frear();
}

class Carro implements Veiculo {

    public void acelerar() {
        System.out.println("Carro acelerando");
    }

    public void frear() {
        System.out.println("Carro freando");
    }
}

public class Exercicio13 {
    public static void main(String[] args) {

        Carro c = new Carro();
        c.acelerar();
        c.frear();
    }
}
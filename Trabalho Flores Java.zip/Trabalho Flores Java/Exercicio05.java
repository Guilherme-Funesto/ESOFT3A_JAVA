/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Mostra números pares de 1 a 20.

Explicação:
O programa usa um laço de repetição de 1 até 20.
Dentro do laço, verifica quais números são pares usando % 2.
Se for par, ele imprime na tela.
*******************************************************************************/

public class Exercicio05 {
    public static void main(String[] args) {

        for (int i = 1; i <= 20; i++) {

            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}
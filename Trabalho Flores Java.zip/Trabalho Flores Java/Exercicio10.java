/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Ordena um array em ordem crescente.

Explicação:
O programa usa dois laços para comparar valores
e trocar de posição (método simples tipo bubble sort).
*******************************************************************************/

public class Exercicio10 {
    public static void main(String[] args) {

        int[] numeros = {5, 2, 9, 1, 3};

        for (int i = 0; i < numeros.length; i++) {
            for (int j = 0; j < numeros.length - 1; j++) {

                if (numeros[j] > numeros[j + 1]) {
                    int temp = numeros[j];
                    numeros[j] = numeros[j + 1];
                    numeros[j + 1] = temp;
                }
            }
        }

        for (int num : numeros) {
            System.out.println(num);
        }
    }
}
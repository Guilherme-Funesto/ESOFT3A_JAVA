/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Calculadora de IMC.

Explicação:
Calcula IMC usando peso e altura e classifica o resultado.
*******************************************************************************/

import java.util.Scanner;

public class Exercicio15 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Peso: ");
        double peso = sc.nextDouble();

        System.out.print("Altura: ");
        double altura = sc.nextDouble();

        double imc = peso / (altura * altura);

        System.out.println("IMC: " + imc);

        if (imc < 18.5)
            System.out.println("Abaixo do peso");
        else if (imc < 25)
            System.out.println("Peso normal");
        else
            System.out.println("Acima do peso");
    }
}
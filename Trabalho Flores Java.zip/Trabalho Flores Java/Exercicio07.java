/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Encontra o maior número em um array.

Explicação:
O programa percorre um array e compara os valores.
Vai guardando o maior número encontrado até o final.
*******************************************************************************/

public class Exercicio07 {
    public static void main(String[] args) {

        int[] numeros = {10, 5, 20, 8, 15};
        int maior = numeros[0];

        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > maior) {
                maior = numeros[i];
            }
        }

        System.out.println("Maior número: " + maior);
    }
}
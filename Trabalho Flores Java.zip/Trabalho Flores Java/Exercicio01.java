/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Programa que soma dois números inteiros.

Explicação:
O programa pede dois números ao usuário, armazena em variáveis
e depois realiza a soma entre eles. Por fim, mostra o resultado na tela.
*******************************************************************************/

import java.util.Scanner;

public class Exercicio01 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int num1 = sc.nextInt();

        System.out.print("Digite o segundo número: ");
        int num2 = sc.nextInt();

        int soma = num1 + num2;

        System.out.println("Soma: " + soma);
    }
}
/******************************************************************************
Curso: Engenharia de Software
Disciplina: Análise e Projeto Orienta a Objetos
Professor: José Carlos Flores
Turma: ESOFT3A
Componentes:
 25068539-2 - Guilherme Costa Ferreira
 24001310-2 - Jonathan de Lima Bellato
 25356144-2 - Lucas Teixeira da Silva
 25356591-2 - Sadrak Araujo

Data: 18/03/2026

Descritivo: Converte temperatura de Celsius para Fahrenheit.

Explicação:
O programa lê uma temperatura em Celsius e aplica a fórmula
F = (C * 9/5) + 32 para converter para Fahrenheit.
Depois mostra o resultado.
*******************************************************************************/

import java.util.Scanner;

public class Exercicio04 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite a temperatura em Celsius: ");
        double c = sc.nextDouble();

        double f = (c * 9/5) + 32;

        System.out.println("Fahrenheit: " + f);
    }
}